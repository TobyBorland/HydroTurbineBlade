"""Sweep across various angles of attack performed in Xfoil and Python.
"""
import numpy as N

import pyxfoil

eng = pyxfoil.give_engine()
eng.read_airfoil('airfoil-naca2412-0.4naca4321.txt')
oper = eng.start(pyxfoil.Oper)
oper.use_visc(1000)

alfas = N.arange(-4, 10.5, 0.5)
coeff_names = ['CL', 'CD', 'CM']
coeffs = N.empty((alfas.shape[0], len(coeff_names)))
cpvs = []
for idx, alfa in enumerate(alfas):
    assert oper.compute_alfa(alfa)
    coeffs[idx, :] = eng.get_many(coeff_names)
    if (idx % 8) == 0:
        cpvs.append((eng.get('xcrds'), eng.get('cpv'), alfa))

oper.write_to('sweep-result.txt', overwrite=True)
# Xfoil ASEQ command
assert oper.compute_aseq(-4, 10, 0.5)
oper.close()

# Plot results with pylab if available
from pyxfoil.postpro import pylab
if pylab is not None:
    P = pylab
    alpha_letter = u'\N{GREEK SMALL LETTER ALPHA}'

    P.figure()
    P.title('Results for mixed airfoil')
    for idx, coeff_name in enumerate(coeff_names):
        P.plot(alfas, coeffs[:, idx], marker='.', label=coeff_name)
    P.xlabel(u'%s [deg]' % alpha_letter)
    P.ylabel('Coefficients')
    P.legend()
    P.grid()

    P.figure()
    for xcrds, cpv, alfa in cpvs:
        P.plot(xcrds, -cpv, label=u'%s = %.1f' % (alpha_letter, alfa))
    P.xlabel('X coordinates')
    P.ylabel('Cp')
    P.legend()

    P.show()
