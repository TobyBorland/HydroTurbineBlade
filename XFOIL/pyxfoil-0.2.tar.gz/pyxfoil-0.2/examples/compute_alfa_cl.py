"""Compute results from the angle of attack in degree (Xfoil ALFA command)
and then from the lift coefficient (Xfoil CL command).
Results can be stored in Python objects for later use.
"""

import pyxfoil
eng = pyxfoil.give_engine()
eng.compute_naca(4321)

oper = eng.start(pyxfoil.Oper)
oper.use_visc(1000)
assert oper.compute_alfa(1)
lcf, dcf = eng.get_many(['CL', 'CD'])
print 'For alfa=1: CL=%.5f, CD=%.5f' % (lcf, dcf)
cpv_data = eng.get('cpv-fig-data')

eng.reset()
oper.use_visc(1000)
assert not oper.compute_cl(0.6)
oper.use_itmax(300)
assert oper.recompute()
print 'For CL=0.6: alfa=%.3f' % eng.get('adeg')
oper.close()

# Optional: plot pressure distribution with Matplotlib
import pyxfoil.postpro as PP
PP.plot_press_distrib(cpv_data, title='Results for alfa=1')
PP.show()

