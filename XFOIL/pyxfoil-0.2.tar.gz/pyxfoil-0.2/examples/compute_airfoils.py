"""Compute NACA airfoils by using Xfoil.
The resulting pyxfoil Airfoil objects are manipulated from Python.
"""

import pyxfoil

eng = pyxfoil.give_engine()
naca4321 = eng.compute_naca(4321)
naca2412 = eng.compute_naca(2412)
name = 'naca2412-0.4naca4321'
mixed = eng.create_mixed_airfoil('mixed', naca2412, naca4321, 0.4)
mixed.save('airfoil-%s.txt' % name, overwrite=True)

# Optional: show airfoils with Matplotlib
import pyxfoil.postpro as PP
PP.plot_airfoil(naca4321)
PP.plot_airfoils([naca4321, naca2412, mixed])
PP.show()

