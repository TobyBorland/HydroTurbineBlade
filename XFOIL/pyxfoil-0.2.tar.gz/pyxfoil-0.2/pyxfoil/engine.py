# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
"""Defines the xfoil engine and its functionalities
"""

import numpy as N

from pyxfoil.utils import (
    Singleton,
    GENERIC,
    LABELED_GENERIC,
    MSES_SINGLE_ELT,
    MSES_MULTI_ELT,
    find_airfoil_file_type,
    carr_to_str,
    check_filename,
    )


class Airfoil(object):
    """The xfoil buffer airfoil
    """

    def __init__(self, eng):
        xcoords, ycoords = eng.give_airfoil_coords()
        assert N.rank(xcoords) == 1
        assert xcoords.shape == ycoords.shape
        self._eng = eng
        self.coords_nb = xcoords.shape[0]
        self.xcoords = xcoords
        self.ycoords = ycoords
        self.name = None
        self.ises_params = None

    def __eq__(self, airf):
        """Test equality between two airfoils"""
        return N.allclose(self.xcoords, airf.xcoords) and \
               N.allclose(self.ycoords, airf.ycoords)

    def place_in_xfoil_memory(self):
        """Place the airfoil in Xfoil interpreter memory"""
        xfoil = self._eng.xfoil
        strings = (
            (xfoil.cc01.name, self.name),
            (xfoil.cc01.ispars, self.ises_params),
        )
        for fsarr, pstr in strings:
            fsarr[:] = ''
            if pstr is not None:
                fsarr[:len(pstr)] = N.array(list(pstr))

        cnb = self.coords_nb
        vecs = (
            (xfoil.cr05.x, self.xcoords),
            (xfoil.cr05.y, self.ycoords),
        )
        xfoil.ci04.n = cnb
        for fcoords, coords in vecs:
            fcoords[:] = 0.
            fcoords[:cnb] = coords

    def save(self, fname, overwrite=False, ftype=LABELED_GENERIC):
        """Save the airfoil in the given filename.
        Use the given airfoil type."""
        check_filename(fname, overwrite)
        eng = self._eng
        swap = False
        if self is not eng.airfoil:
            swap = True
            self.place_in_xfoil_memory()

        # Xfoil never saves GENERIC airfoil file
        if ftype is GENERIC:
            ftype = LABELED_GENERIC
        eng.xfoil.save(ftype.idx - 1, fname)

        if swap:
            eng.airfoil.place_in_xfoil_memory()


class ComputedAirfoil(Airfoil):
    """An airfoil computed by Xfoil
    """

    def __init__(self, eng):
        Airfoil.__init__(self, eng)
        self.name = eng.give_airfoil_name()


class LoadedAirfoil(Airfoil):
    """An airfoil read from a file by Xfoil
    """

    def __init__(self, eng, fname, ftype):
        Airfoil.__init__(self, eng)
        name = None
        if ftype.idx > 1:
            name = eng.give_airfoil_name()
        ises_params = None
        if ftype.idx > 2:
            ises_params = eng.give_ises_params()

        self.name = name
        self.ises_params = ises_params
        self.ftype = ftype
        self.fname = fname


class Session(object):
    """A commands session
    """

    def __init__(self, eng):
        self._eng = eng

    def reset(self):
        """Reset the session variables to default"""
        pass


class Oper(Session):
    """A session in the oper mode
    """

    def __init__(self, eng):
        Session.__init__(self, eng)
        self._current_calc = None

    def reset(self):
        """Reset the variables modified by the Oper session to default"""
        self._current_calc = None
        self._eng.xfoil.cr09.adeg = 0.

    def use_visc(self, reynolds_nb):
        """Use the given reynolds number"""
        xfoil = self._eng.xfoil
        xfoil.cl01.lvisc = True
        xfoil.cr15.reinf1 = reynolds_nb
        xfoil.cl01.lvconv = False

    def use_itmax(self, itmax):
        """Use the maximum number of Newton iterations"""
        self._eng.xfoil.ci04.itmax = itmax

    def write_to(self, fname, overwrite=False):
        """Write polar results to the given filename"""
        check_filename(fname, overwrite)
        self._eng.xfoil.writepr(fname)

    def compute_alfa(self, alfa):
        """Compute results from the given alfa angle.
        Return True in case the simulation converged."""
        xfoil = self._eng.xfoil
        xfoil.salfa(alfa)
        self._current_calc = xfoil.calfa
        return self.recompute()

    def compute_cl(self, lift_coeff):
        """Compute results from the lift coefficient.
        Return True in case the simulation converged."""
        xfoil = self._eng.xfoil
        xfoil.scl(lift_coeff)
        self._current_calc = xfoil.ccl
        return self.recompute()

    def compute_aseq(self, start, stop, step):
        """Compute results for various angles of attack.
        Return True in case the simulation converged."""
        xfoil = self._eng.xfoil
        xfoil.aseq(start, stop, step)
        return bool(xfoil.cl01.lvconv)

    def recompute(self):
        """Continue iterating on the last computation run.
        Return True in case the simulation converged."""
        calc = self._current_calc
        if calc is None:
            raise ValueError('No calcul defined')
        calc()
        return bool(self._eng.xfoil.cl01.lvconv)

    def close(self):
        """Close the session, the xfoil default mode will come back"""
        self._eng.xfoil.cloper()


class XfoilParams(object):
    """Retrieve xfoil parameters
    """

    def __init__(self, eng):
        self._eng = eng
        self._xfoil = eng.xfoil

    def give_re1(self):
        """Convert to float CR15.REINF1"""
        return float(self._xfoil.cr15.reinf1)

    def give_mach1(self):
        """Convert to float CR09.MINF1"""
        return float(self._xfoil.cr09.minf1)

    def give_n(self):
        """Convert to int CI04.N"""
        return int(self._xfoil.ci04.n)

    def give_nw(self):
        """Convert to int CI04.NW"""
        return int(self._xfoil.ci04.nw)

    def calc_tnb(self):
        """Return n + nw"""
        return self.give_n() + self.give_nw()

    def give_xcrds(self):
        """Copy CR05.X[:tnb]"""
        return self._xfoil.cr05.x[:self.calc_tnb()].copy()

    def give_adeg(self):
        """Convert to float CR09.ADEG"""
        return float(self._xfoil.cr09.adeg)

    def give_cl(self):
        """Convert to float CR09.CL"""
        return float(self._xfoil.cr09.cl)

    def give_cd(self):
        """Convert to float CR09.CD"""
        return float(self._xfoil.cr09.cd)

    def give_cdp(self):
        """Convert to float CR09.CDP"""
        return float(self._xfoil.cr09.cdp)

    def give_cm(self):
        """Convert to float CR09.CM"""
        return float(self._xfoil.cr09.cm)

    def give_cpv(self):
        """Copy CR04.CPV[:tnb]"""
        return self._xfoil.cr04.cpv[:self.calc_tnb()].copy()

    def give_cpi(self):
        """Copy CR04.CPI[:tnb]"""
        return self._xfoil.cr04.cpi[:self.calc_tnb()].copy()

    def build_top_slice(self):
        """Return Python slice equivalent to 1:CI05.IPAN(2, 1)"""
        return slice(0, int(self._xfoil.ci05.ipan[1, 0]))

    def build_bot_slice(self):
        """Return Python slice equivalent to CI05.IPAN(2, 2):CI04.N"""
        return slice(int(self._xfoil.ci05.ipan[1, 1]) - 1, self.give_n())

    def build_wake_slice(self):
        """Return Python slice equivalent to (CI04.N+1):(CI04.NW+CIO4.N)"""
        return slice(self.give_n(), self.calc_tnb())

    def build_cpv_fig_data(self):
        """Return data for plotting pressure distribution"""
        return (
            self.give_xcrds(),
            self.give_cpv(),
            self.give_cpi(),
            self.build_top_slice(),
            self.build_bot_slice(),
            self.build_wake_slice()
        )

    def give_top_xtr(self):
        """Convert to float CR15.XOCTR(1)"""
        return float(self._xfoil.cr15.xoctr[0])

    def give_bot_xtr(self):
        """Convert to float CR15.XOCTR(2)"""
        return float(self._xfoil.cr15.xoctr[1])

    def give_acrit(self):
        """Convert to float CR15.ACRIT"""
        return float(self._xfoil.cr15.acrit)


class Engine(Singleton):
    """The xfoil engine available from Python
    """

    def init(self):
        """Initialize the Xfoil engine"""
        import pyxfoil.fengine as xfoil
        xfoil.init()
        # No graphical output
        xfoil.ci04.idev = 0
        xfoil.cr01.version = 6.97
        self.xfoil = xfoil
        self.airfoil = None
        self._sessions = {
            Oper : Oper(self),
        }

        prs = XfoilParams(self)
        self.params = prs
        self._get_param = {
            'Re1' : prs.give_re1,
            'Mach1' : prs.give_mach1,

            'anb' : prs.give_n,
            'wnb' : prs.give_nw,
            'xcrds' : prs.give_xcrds,

            'adeg' : prs.give_adeg,
            'CL' : prs.give_cl,
            'CD' : prs.give_cd,
            'CDp' : prs.give_cdp,
            'CM' : prs.give_cm,

            'cpv' : prs.give_cpv,
            'cpi' : prs.give_cpi,
            'top-slice' : prs.build_top_slice,
            'bot-slice' : prs.build_bot_slice,
            'wake-slice' : prs.build_wake_slice,
            'cpv-fig-data' : prs.build_cpv_fig_data,

            'Top_Xtr' : prs.give_top_xtr,
            'Bot_Xtr' : prs.give_bot_xtr,

            'acrit' : prs.give_acrit,
        }

    def reset(self):
        """Reset the Fortran Xfoil interpreter to initial state"""
        xfoil = self.xfoil
        xfoil.init()
        xfoil.ci04.idev = 0
        for session in self._sessions.values():
            session.reset()

    def compute_naca(self, digits):
        """Ask xfoil to compute the given naca airfoil from 4 or
        5 digits"""
        self.xfoil.naca(digits)
        airfoil = ComputedAirfoil(self)
        self.airfoil = airfoil
        return airfoil

    def read_airfoil(self, fname):
        """Read an airfoil stored inside a file and use it as current
        airfoil"""
        itype = self.xfoil.pload(fname)
        ftype = find_airfoil_file_type(itype)
        airfoil = LoadedAirfoil(self, fname, ftype)
        self.airfoil = airfoil
        return airfoil

    def give_airfoil_name(self):
        """Return the current airfoil name"""
        return carr_to_str(self.xfoil.cc01.name)

    def use_airfoil_name(self, name):
        """Use the given airfoil name in Xfoil"""
        xfoil = self.xfoil
        name_len = len(name)
        xfoil.ci01.nname = name_len
        aname = xfoil.cc01.name
        aname[:] = ''
        aname[:name_len] = N.array(list(name))

    def give_ises_params(self):
        """Return the current ISES parameters"""
        return carr_to_str(self.xfoil.cc01.ispars)

    def give_airfoil_coords(self):
        """Return the current airfoil coordinates"""
        xfoil = self.xfoil
        coords_nb = xfoil.ci04.n
        return (
            xfoil.cr05.x[:coords_nb].copy(),
            xfoil.cr05.y[:coords_nb].copy(),
        )

    def create_mixed_airfoil(self, name, airfoil1, airfoil2, frac=0.5):
        """Create a new airfoil by interpolating the first airfoil with
        a fraction of the second."""
        airfs = [airfoil1, airfoil2]
        arrs = [N.zeros((airf.coords_nb, 2), float) for airf in airfs]
        for airf, arr in zip(airfs, arrs):
            arr[:, 0] = airf.xcoords
            arr[:, 1] = airf.ycoords
        self.xfoil.pinte(arrs[0], arrs[1], frac)
        self.xfoil.pangen(False)
        self.use_airfoil_name(name)
        airfoil = ComputedAirfoil(self)
        self.airfoil = airfoil
        return airfoil

    def start(self, session_type):
        """Start a sessions corresponding to a XFoil mode (oper, gdes)"""
        return self._sessions[session_type]

    def get(self, var_name):
        """Return an Xfoil variable value from its name.
        The possible variable names are:

            - 'Re1' : Reynolds number  Vinf c / ve  for CL=1
            - 'Mach1' : freestream Mach number at CL=1

            - 'anb' : number of airfoil points
            - 'wnb' : number of wake points
            - 'xcrds' : coordinates along the X axis

            - 'adeg' : angle of attack in degrees
            - 'CL' : current CL calculated from GAM(.) distribution
            - 'CD' : current CD from BL solution
            - 'CDp' : current CD press
            - 'CM' : current CM calculated from GAM(.) distribution

            - 'cpv' : viscous pressure distribution
            - 'cpi' : inviscid pressure distribution
            - 'top-slice' : indexes for getting top pressures
            - 'bot-slice' : indexes for getting bottow pressures
            - 'wake-slice' : indexes for getting wake pressures
            - 'cpv-fig-data' : xcrds, cpv, cpi and slices for plotting
            pressure distribution

            - 'Top_Xtr' : top actual transition x/c location
            - 'Bot_Xtr' : bottom actual transition x/c location

            - 'acrit' : log (critical amplification ratio)

        """
        return self._get_param[var_name]()

    def get_many(self, var_names):
        """Return Xfoil variable values from their name. See the get
        method for possible variable names."""
        return [self.get(var_name) for var_name in var_names]


def give_engine():
    """Return the xfoil engine by building it at the first call.
    Only one xfoil engine can exist in the same process because xfoil
    common variables are shared."""
    return Engine()


