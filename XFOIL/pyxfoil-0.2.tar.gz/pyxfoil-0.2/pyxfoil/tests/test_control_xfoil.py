# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
"""Check the xfoil interpreter control
"""
from re import match
import unittest as UT

import numpy as N

import pyxfoil

import pyxfoil.tests as PT



class TestControlXfoil(UT.TestCase):

    def setUp(self):
        self.eng = pyxfoil.give_engine()
        self.tdir = PT.TestDir('control-xfoil')

    def tearDown(self):
        self.tdir.clean()
        self.eng.reset()

    def test_reset_interpreter_to_default(self):
        eng = pyxfoil.give_engine()
        xfoil = eng.xfoil

        eng.compute_naca(4321)
        oper = eng.start(pyxfoil.Oper)
        oper.use_visc(1000)
        self.assert_(xfoil.cl01.lvisc)
        self.assertEqual(xfoil.cr15.reinf1, 1e3)
        oper.compute_alfa(1)
        self.assert_(xfoil.cl01.lvconv)
        self.assertEqual(xfoil.cr09.adeg, 1.)
        self.assert_(abs(float(xfoil.cr09.cl) + 0.1099397838) <= 1e-10)
        oper.close()

        eng.reset()
        self.assert_(not xfoil.cl01.lvisc)
        self.assertEqual(xfoil.cr15.reinf1, 0.)
        self.assert_(not xfoil.cl01.lvconv)
        self.assertEqual(xfoil.cr09.adeg, 0.)
        self.assertEqual(xfoil.cr09.cl, 0.)
        self.assertRaises(ValueError, oper.recompute)

    def test_compute_airfoils_to_python_objects(self):
        eng = self.eng
        naca4321 = eng.compute_naca(4321)
        fname = self.tdir.add_fname('naca4321.txt')
        naca4321.save(fname)
        fnaca4321 = N.loadtxt(fname, skiprows=1)
        self.assert_(naca4321 is eng.airfoil)

        naca4221 = eng.compute_naca(4221)
        fname = self.tdir.add_fname('naca4221.txt')
        naca4221.save(fname)
        fnaca4221 = N.loadtxt(fname, skiprows=1)
        self.assert_(naca4221 is eng.airfoil)
        self.assert_(naca4221 is not naca4321)
        self.assert_(not N.allclose(fnaca4321, fnaca4221))

        self.assertEqual(naca4321.name, 'NACA 4321')
        self.assertEqual(naca4321.coords_nb, fnaca4321.shape[0])
        self.assert_(N.allclose(naca4321.xcoords, fnaca4321[:, 0]))
        self.assert_(N.allclose(naca4321.ycoords, fnaca4321[:, 1]))

        self.assertEqual(naca4221.name, 'NACA 4221')
        self.assertEqual(naca4221.coords_nb, fnaca4221.shape[0])
        self.assert_(N.allclose(naca4221.xcoords, fnaca4221[:, 0]))
        self.assert_(N.allclose(naca4221.ycoords, fnaca4221[:, 1]))

    def test_load_airfoils_to_python_objects(self):
        fname = self.tdir.add_fname('naca4321.txt')
        eng = self.eng
        airfoil = eng.compute_naca(4321)
        airfoil.save(fname)
        eng.reset()

        eng.compute_naca(4221)
        airfoil = eng.read_airfoil(fname)
        self.assert_(airfoil is eng.airfoil)
        fcoords = N.loadtxt(fname, skiprows=1)
        self.assertEqual(airfoil.name, 'NACA 4321')
        self.assertEqual(airfoil.coords_nb, fcoords.shape[0])
        self.assert_(N.allclose(airfoil.xcoords, fcoords[:, 0]))
        self.assert_(N.allclose(airfoil.ycoords, fcoords[:, 1]))
        self.assert_(airfoil.ftype is pyxfoil.LABELED_GENERIC)
        self.assertEqual(airfoil.fname, fname)

    def test_save_airfoils_from_python_objects(self):
        fnaca4321 = self.tdir.add_fname('naca4321.txt')
        fnaca4221 = self.tdir.add_fname('naca4221.txt')
        eng = self.eng

        naca4321 = eng.compute_naca(4321)
        naca4221 = eng.compute_naca(4221)
        naca4321.save(fnaca4321)
        naca4221.save(fnaca4221)

        airf = eng.read_airfoil(fnaca4321)
        self.assertEqual(airf, naca4321)
        airf = eng.read_airfoil(fnaca4221)
        self.assertEqual(airf, naca4221)

    def test_allow_to_overwrite_airfoil_files(self):
        fname = self.tdir.add_fname('airfoil.txt')
        eng = self.eng

        airf = eng.compute_naca(4321)
        airf.save(fname)
        self.assertRaises(IOError, airf.save, fname)
        airf.save(fname, overwrite=True)

    def test_access_xfoil_variables(self):
        fname = self.tdir.add_fname('results.txt')
        eng = self.eng

        airf = eng.compute_naca(4321)
        oper = eng.start(pyxfoil.Oper)
        oper.use_visc(1000)
        oper.write_to(fname)
        self.assert_(oper.compute_alfa(1))
        oper.close()

        fid = open(fname)
        lines = fid.readlines()
        fid.close()
        pattern = ' Mach = (.+) Re = (.+) Ncrit = (.+)'
        grps = match(pattern, lines[8]).groups()
        mach, rey_nb, ncrit = [float(grp.replace(' ', '')) for grp in grps]
        vals = [float(sval) for sval in lines[-1].split()]

        self.assertEqual(eng.get('Re1'), rey_nb)
        self.assertEqual(eng.get_many(['Mach1', 'acrit']), [mach, ncrit])
        vnames = ['adeg', 'CL', 'CD', 'CDp', 'CM', 'Top_Xtr', 'Bot_Xtr']
        xvals = eng.get_many(vnames)
        self.assert_(N.allclose(xvals, vals, atol=1e-4),
                     '%s != %s' % (xvals, vals))


if __name__ == '__main__':
    PT.run_tests()

