# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
"""Validation tests on user stories
"""
import os
import unittest as UT

import numpy as N

import pyxfoil

import pyxfoil.tests as PT


class TestRunStories(UT.TestCase):

    def setUp(self):
        self.tdir = PT.TestDir('run-stories')
        self.add_fname = self.tdir.add_fname
        self.eng = pyxfoil.give_engine()

    def tearDown(self):
        self.tdir.clean()
        self.eng.reset()

    def check_content(self, fnma, fnmb):
        fnames = "'%s' and '%s'" % (fnma, fnmb)
        lines = []
        for fnm in (fnma, fnmb):
            fid = open(fnm)
            lines.append(fid.readlines())
            fid.close()

        lines_nb = len(lines[0])
        self.assert_(lines_nb == len(lines[1]),
                     fnames + ' have different length')
        diffs = []
        for lidx in xrange(lines_nb):
            dlines = [lines[fidx][lidx].strip() for fidx in xrange(2)]
            if dlines[0] != dlines[1]:
                diffs.extend([
                    '> ' + dlines[0],
                    '< ' + dlines[1],
                    '',
                ])
        if diffs:
            diffs.insert(0, fnames + ' are different')
            self.fail(os.linesep.join(diffs))

    def test_export_airfoil_data(self):
        fname = self.add_fname('airfoil.txt')
        eng = self.eng
        airfoil = eng.compute_naca(4321)
        airfoil.save(fname)

        xfname = self.add_fname('airfoil-xfoil.txt')
        PT.run_session([
            'naca 4321',
            'save %s' % xfname,
        ])
        self.check_content(fname, xfname)

    def test_compute_coeffs_from_attack_angle(self):
        fname = self.add_fname('coeffs.txt')
        eng = self.eng
        eng.compute_naca(4321)
        oper = eng.start(pyxfoil.Oper)
        oper.use_visc(1000)
        oper.write_to(fname)
        self.assert_(oper.compute_alfa(1))
        oper.close()

        xfname = self.add_fname('coeffs-xfoil.txt')
        PT.run_session([
            'naca 4321',
            'oper',
            'visc 1000',
            'pacc',
            xfname,
            '',
            'alfa 1',
            '',
        ])

        self.check_content(fname, xfname)

    def test_compute_attack_angle_from_cl(self):
        fname = self.add_fname('alfa.txt')
        eng = self.eng
        eng.compute_naca(4321)
        oper = eng.start(pyxfoil.Oper)
        oper.use_visc(1000)
        oper.write_to(fname)
        self.assert_(not oper.compute_cl(0.6))
        oper.use_itmax(300)
        self.assert_(oper.recompute())
        oper.close()

        xfname = self.add_fname('alfa-xfoil.txt')
        PT.run_session([
            'naca 4321',
            'oper',
            'visc 1000',
            'pacc',
            xfname,
            '',
            'cl 0.6',
            'iter 300',
            '!',
            '',
        ])

        self.check_content(fname, xfname)

    def test_load_airfoil_data_from_file(self):
        add_fname = self.add_fname
        airfoil_fname = add_fname('naca4321.txt')
        PT.run_session([
            'naca 4321',
            'save %s' % airfoil_fname,
        ])

        cmds = [
            'oper',
            'visc 1000',
            'pacc',
            None,
            '',
            'alfa 1',
            '',
        ]
        rfnames = {
            'from-computed' : add_fname('res-from-computed-airfoil.txt'),
            'from-loaded' : add_fname('res-from-loaded-airfoil.txt'),
            'from-pyxfoil' : add_fname('res-from-pyxfoil.txt'),
        }
        cmds[3] = rfnames['from-computed']
        PT.run_session(['naca 4321'] + cmds)
        cmds[3] = rfnames['from-loaded']
        PT.run_session(['load %s' % airfoil_fname] + cmds)
        self.check_content(rfnames['from-loaded'], rfnames['from-computed'])

        eng = self.eng
        eng.read_airfoil(airfoil_fname)
        oper = eng.start(pyxfoil.Oper)
        oper.use_visc(1000)
        oper.write_to(rfnames['from-pyxfoil'])
        self.assert_(oper.compute_alfa(1))
        oper.close()
        self.check_content(rfnames['from-loaded'], rfnames['from-pyxfoil'])

    def test_sweep_across_various_angles_of_attack(self):
        fname = self.add_fname('pyxfoil-sweep.txt')
        eng = self.eng
        eng.compute_naca(4321)
        oper = eng.start(pyxfoil.Oper)
        oper.use_visc(1000)
        oper.write_to(fname)
        self.assert_(oper.compute_aseq(-4, 10, 0.5))
        oper.close()

        xfname = self.add_fname('xfoil-sweep.txt')
        PT.run_session([
            'naca 4321',
            'oper',
            'visc 1000',
            'pacc',
            xfname,
            '',
            'aseq -4 10 0.5',
            '',
        ])

        self.check_content(fname, xfname)

    def test_mix_airfoils(self):
        aname = 'naca2412-0.1naca4321'
        fname = self.add_fname('%s.txt' % aname)
        eng = self.eng

        naca2412 = eng.compute_naca(2412)
        naca4321 = eng.compute_naca(4321)
        mairf = eng.create_mixed_airfoil(aname, naca2412, naca4321, 0.1)
        self.assert_(eng.airfoil is mairf)
        self.assertEqual(mairf.name, aname)
        mairf.save(fname)

        xnaca_fname = self.add_fname('naca4321-xfoil.txt')
        xfname = self.add_fname('%s-xfoil.txt' % aname)
        PT.run_session([
            'naca 4321',
            'save %s' % xnaca_fname,
            'naca 2412',
            'inte',
            'c',
            'f',
            xnaca_fname,
            '0.1',
            aname,
            'pane',
            'save %s' % xfname,
        ])

        res = N.loadtxt(fname, skiprows=1)
        xres = N.loadtxt(xfname, skiprows=1)
        self.assert_(N.allclose(res, xres, atol=1e-6))
        fids = [open(fname), open(xfname)]
        self.assertEqual(fids[0].readline(), fids[1].readline())
        for fid in fids:
            fid.close()


if __name__ == '__main__':
    PT.run_tests()

