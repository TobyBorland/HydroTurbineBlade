# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
"""The postpro module should print a warning without matplotlib
"""
import sys
import logging
import unittest as UT
from os import linesep
from cStringIO import StringIO

import pyxfoil


class TestRunWithoutPylab(UT.TestCase):

    def setUp(self):
        self.log = StringIO()
        hdl = logging.getLogger().handlers[0]
        self._hdl_stream = hdl.stream
        hdl.stream = self.log
        self._hdl = hdl

        import __builtin__ as blt
        bimport = blt.__import__
        def no_pylab_import(*args):
            if args[0] == 'pylab':
                raise ImportError
            return bimport(*args)
        blt.__import__ = no_pylab_import
        import pyxfoil.postpro
        blt.__import__ = bimport

        self.postpro = pyxfoil.postpro

    def tearDown(self):
        del sys.modules['pyxfoil.postpro']
        self._hdl.stream = self._hdl_stream

    def test_print_warning_during_import(self):
        mess = linesep.join([
            'The pylab module is not available.',
            'Functions from the pyxfoil.postpro module will not work.',
        ]) + linesep
        self.assertEqual(self.log.getvalue(), mess)

    def test_run_every_pylab_function(self):
        PP = self.postpro
        PP.plot_airfoil(None)
        PP.plot_airfoils([])
        PP.plot_press_distrib(None)
        PP.show()

        self.log.seek(0)
        self.assertEqual(len(self.log.readlines()), 2)


if __name__ == '__main__':
    UT.main()

