# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
"""Tools for testing
"""
import os.path as osp
from tempfile import mkdtemp
from shutil import rmtree
from sys import argv as sargv
from unittest import main


from pyxfoil.tests.xfoil_cmd import use_xfoil_cmd


class TestDir(object):
    """A test directory where files are added
    """

    def __init__(self, suffix):
        self.path = mkdtemp(suffix)

    def add_fname(self, fname):
        """Add a filename to the directory"""
        return osp.join(self.path, fname)

    def clean(self):
        """Clean the directory"""
        rmtree(self.path)


def run_tests():
    """Try to find the Xfoil command from sys.argv. Useful
    for not altering the unittest mechanism"""
    if '-cmd' in sargv:
        idx = sargv.index('-cmd')
        use_xfoil_cmd(osp.abspath(sargv[idx + 1]))
        del sargv[idx:idx + 2]
    main()


