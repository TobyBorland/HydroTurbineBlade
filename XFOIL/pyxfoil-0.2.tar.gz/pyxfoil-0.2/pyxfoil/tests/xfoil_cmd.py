# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
"""Control the xfoil command from Python
"""
import select
import subprocess as SP


class XfoilSession(object):
    """An Xfoil session where to enter commands.
    However the standard output can not be got interactively.
    """
    xfoil_cmd = None

    def __init__(self, xfoil_cmd=None, no_graph=True):
        cmd = xfoil_cmd or self.xfoil_cmd
        if cmd is None:
            raise ValueError('No Xfoil command provided')
        popen = SP.Popen(cmd, stdin=SP.PIPE, stdout=SP.PIPE)
        spoll = select.poll()
        spoll.register(popen.stdout, select.POLLIN)
        self._popen = popen
        self._poll = spoll.poll
        if no_graph:
            self.toggle_graph()

    def enter(self, cmd):
        """Enter the given command to xfoil interpreter"""
        self._popen.stdin.write(cmd + '\n')

    def enter_many(self, cmds):
        """Enter the sequence of commands"""
        for cmd in cmds:
            self.enter(cmd)

    def toggle_graph(self):
        """Toggle graphical output (should be set to False else the subprocess
        should fail)"""
        self.enter_many([
            'plop',
            'G',
            '',
        ])

    def quit(self):
        """Quit the xfoil interpreter and return the subprocess status"""
        self.enter('quit')
        return self._popen.wait()

    def give_output(self, timeout=1):
        """Give the output stream if ready else return None. The default
        timeout is one second."""
        if self._poll(timeout):
            return self._popen.stdout


def use_xfoil_cmd(cmd):
    """Use the given xfoil executable for sessions"""
    XfoilSession.xfoil_cmd = cmd

def run_session(cmds, xfoil_cmd=None):
    """Run a complete xfoil session with the given commands"""
    session = XfoilSession(xfoil_cmd)
    session.enter_many(cmds)
    session.quit()


