# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
"""pyxfoil package identifiers
"""


VERSION = '0.2'


def setup_logger():
    """Setup for messages logging"""
    import logging
    from sys import stdout
    logger = logging.getLogger()
    logger.addHandler(logging.StreamHandler(stdout))

setup_logger()

from pyxfoil.engine import (
    give_engine,
    Oper,
    GENERIC,
    LABELED_GENERIC,
    MSES_SINGLE_ELT,
    MSES_MULTI_ELT
)

