# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
"""Common Python tools for wrapping Xfoil
"""
import os
import os.path as osp


class Singleton(object):
    """Singleton implementation in python.
    """
    _inst = None

    def __new__(cls):
        if cls._inst is None:
            inst = object.__new__(cls)
            inst.init()
            cls._inst = inst
        return cls._inst

    def init(self):
        """Initialize the singleton instance"""
        pass


class AirfoilFileType(object):
    """Xfoil airfoil file type with its index and label
    """

    def __init__(self, idx, label):
        self.idx = idx
        self.label = label

    def __repr__(self):
        """Return its label"""
        return 'Airfoil file type: %s, idx: %i' % (self.label, self.idx)


GENERIC = AirfoilFileType(1, 'Generic')
LABELED_GENERIC = AirfoilFileType(2, 'Labeled generic')
MSES_SINGLE_ELT = AirfoilFileType(3, 'MSES single element')
MSES_MULTI_ELT = AirfoilFileType(4, 'MSES multi-element')

AIRFOIL_FILE_TYPES = (
    GENERIC,
    LABELED_GENERIC,
    MSES_SINGLE_ELT,
    MSES_MULTI_ELT,
)

AIRFOIL_FILE_IDXS = [ftype.idx for ftype in AIRFOIL_FILE_TYPES]


def find_airfoil_file_type(itype):
    """Find the airfoil file type from Xfoil index (itype)"""
    return AIRFOIL_FILE_TYPES[AIRFOIL_FILE_IDXS.index(itype)]

def carr_to_str(sarr):
    """Convert an array made of characters to Python str"""
    return ''.join(sarr).strip()

def check_filename(fname, overwrite):
    """Check that the filename is correct for Xfoil"""
    assert len(fname) <= 64
    if overwrite and osp.exists(fname):
        os.remove(fname)
    if osp.exists(fname):
        raise IOError('Filename "%s" exists' % fname)


