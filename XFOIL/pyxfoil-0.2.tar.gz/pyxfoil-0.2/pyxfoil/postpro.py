# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
"""Post processing functions using Matplotlib.

This module illustrates how Python can be used to imitate Xfoil
figures.
"""


pylab = None


def init_pylab():
    """Import the pylab module if available"""
    global pylab
    try:
        import pylab
    except ImportError:
        from logging import warning as warn
        warn('The pylab module is not available.')
        warn('Functions from the pyxfoil.postpro module will not work.')


init_pylab()


def plot_airfoil(airfoil):
    """Plot the pyxfoil.Airfoil object on a Matplotlib figure"""
    if pylab is None:
        return
    P = pylab
    P.figure()
    P.title(airfoil.name)
    P.plot(airfoil.xcoords, airfoil.ycoords)
    P.axis('equal')
    P.grid()

def plot_airfoils(airfoils):
    """Plot several pyxfoil.Airfoil objects on a Matplotlib figure"""
    if pylab is None:
        return
    P = pylab
    P.figure()
    for airf in airfoils:
        P.plot(airf.xcoords, airf.ycoords, label=airf.name)
    P.legend()
    P.axis('equal')
    P.grid()

def plot_press_distrib(cpv_data, title="Pressure distributions"):
    """Plot pressure distribution with cpv data made of:

        - x coordinates
        - viscous pressure distribution
        - inviscid pressure distribution
        - indexes for top pressures
        - indexes for bottow pressures
        - indexes for wake pressures

    """
    if pylab is None:
        return
    P = pylab
    xcrds, cpv, cpi, tsl, bsl, wsl = cpv_data
    P.plot(xcrds[tsl], -cpv[tsl], color='red', label='Top Cpv')
    P.plot(xcrds[bsl], -cpv[bsl], color='blue', label='Bottom Cpv')
    P.plot(xcrds[wsl], -cpv[wsl], color='black', label='Wake Cpv')
    P.plot(xcrds, -cpi, color='grey', linestyle='--', label='Cpi')
    P.xlabel('X coordinates')
    P.ylabel('Cp')
    P.legend()
    P.grid()

def show():
    """Show figures if pylab module is available."""
    if pylab is None:
        return
    pylab.show()


