# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
import os

Import('env nenv xfoil_objs')

def run_f2py(target, source, env):
    """Run the f2py command for building the Python module"""
    module = os.path.splitext(str(target[0]))[0]
    srcs = ' '.join([str(src) for src in source])
    cmd = 'f2py -m %s -c %s -Lbuild -lxfoil 1> f2py-log.txt'
    env.Execute(cmd % (module, srcs))

xfoil_lib = env.SharedLibrary('#build/xfoil', [
    'xfoil.F',
    'xpol.F',
    'xoper.F',
    'xgeom.F',
    'xbl.F',
    'xpanel.F',
    'lxfoil.f',
    'loper.f',
    'lpol.f',
] + xfoil_objs,
FORTRANPATH=['#Xfoil/src'], CPPDEFINES=['XFLIB'], LIBS=['X11'])

fengine = env.Command(
    '#fengine.so',
    ['pyxfoil.pyf'],
    run_f2py)
Depends(fengine, xfoil_lib)
Return('fengine')

