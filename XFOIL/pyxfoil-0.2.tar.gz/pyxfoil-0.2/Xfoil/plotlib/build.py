# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
Import('env')
xwin = env.SharedObject(['Xwin.c'], CPPDEFINES=['UNDERSCORE'])
plt = env.SharedObject([
    'plt_base.f',
    'plt_font.f',
    'plt_util.f',
    'plt_color.f',
    'set_subs.f',
    'gw_subs.f',
    'ps_subs.f',
    'plt_old.f',
    'plt_3D.f',
])
plt_objs = xwin + plt
Return('plt_objs')
