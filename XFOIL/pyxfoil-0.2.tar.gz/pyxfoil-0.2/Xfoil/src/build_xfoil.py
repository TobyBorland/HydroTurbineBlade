# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
Import('env nenv lib_plt osrc_objs')
objs = env.Object([
    'xpanel.f',
    'xsolve.f',
    'dplot.f',
])
nobjs = nenv.Object([
    'xfoil.f',
    'xoper.f',
    'xtcam.f',
    'xgdes.f',
    'xqdes.f',
    'xmdes.f',
    'xbl.f',
    'xblsys.f',
    'xpol.f',
    'xplots.f',
    'pntops.f',
    'xgeom.f',
    'xutils.f',
    'modify.f',
    'blplot.f',
    'polplt.f',
    'aread.f',
    'naca.f',
    'spline.f',
    'plutil.f',
    'iopol.f',
    'gui.f',
    'sort.f',
    'profil.f',
    'userio.f',
    'frplot.f',
    'ntcalc.f',
])
xfoil = env.Program(
    'xfoil',
     objs + nobjs + lib_plt+ osrc_objs,
     LIBS=['X11'])
Return('xfoil')

