# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
import os

def generate_data(target, source, env):
    """Generate data by using the osgen program"""
    os.system('cd orrs && ./src/osgen osmaps_ns.lst')

Import('env')
osgen, osmap_obj = SConscript('src/build_xfoil.py', exports='env')
run_osgen = env.Command('osgen-done', osgen, [generate_data, Touch('$TARGET')])
Depends(run_osgen, osmap_obj)
Return('osmap_obj')
