# -*- coding: utf-8 -*-
# This file is part of pyxfoil
# Copyright (C) 2010 André ESPAZE (andre.espaze@logilab.fr)
# pyxfoil is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
"""Compare pyxfoil results with the original xfoil program
"""
from os.path import abspath
import unittest as UT
from optparse import OptionParser

import pyxfoil.tests as PT
from pyxfoil.tests import (
    test_control_xfoil,
    test_run_user_stories,
    test_allow_pylab_postpro,
)


def main():
    """Run Pyxfoil validation tests"""
    parser = OptionParser()
    parser.add_option('-c', '--xfoil-cmd',
                      default='./Xfoil/xfoil',
                      help='xfoil executable used for comparing results')
    opts = parser.parse_args()[0]
    PT.use_xfoil_cmd(abspath(opts.xfoil_cmd))

    load = UT.TestLoader().loadTestsFromModule
    suite = UT.TestSuite()
    suite.addTests(load(test_control_xfoil))
    suite.addTests(load(test_run_user_stories))
    suite.addTests(load(test_allow_pylab_postpro))
    runner = UT.TextTestRunner()
    runner.run(suite)

if __name__ == '__main__':
    main()

