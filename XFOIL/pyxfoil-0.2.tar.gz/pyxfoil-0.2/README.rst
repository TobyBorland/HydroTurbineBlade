Xfoil for Python
================
The goal is to wrap some of the XFoil functionalities to Python, see:

    http://www.python-science.org/project/pyxfoil

for the project tracker. The license is GPL version 2.

Prerequisites
-------------
For building pyxfoil, the following tools are required:

    - Python http://www.python.org (tested with 2.5.2 and 2.6.2)
    - Scons http://www.scons.org/ (tested with v1.0.0 and 1.2.0)
    - C and Fortran compilers, currently the only one tested is:
        * gcc/gfortran http://gcc.gnu.org/ (tested with 4.3.2 and 4.3.3)
    - Numpy http://numpy.scipy.org/ (tested with 1.1.0 and 1.2.1)

The Xfoil sources are shipped with pyxfoil.
Once installed, the pyxfoil use requires:

    - Python
    - Numpy

For specific distributions, look at the appendix on distributions
prerequisites.

This package is optional but can be used for plotting Xfoil results:

    - Matplotlib http://matplotlib.sf.net/ (tested with 0.98.1)

For an interactive use of pyxfoil, you may also like to have the enhanced
interactive Python shell:

    - Ipython http://ipython.scipy.org/ (tested with 0.8.4)


Building pyxfoil
----------------
The pyxfoil module as well as the xfoil shared library can be built by::

    $ scons -Q

Running validation tests (optional)
-----------------------------------
The validation tests will compare the pyxfoil results with the original
xfoil program. If you do not have xfoil on your system, you can build
it by::

    $ scons -C Xfoil -Q

If you would like to run a manual test on xfoil::

    $ ./Xfoil/xfoil
    c> naca 4321
    c> oper
    c> visc 1000
    c> alfa 1
    c> <enter>
    c> quit

The validation tests can now be run by::

    $ LD_LIBRARY_PATH=build:$LD_LIBRARY_PATH \
    python run_tests.py -c ./Xfoil/xfoil

You may provide your own xfoil command to the '-c' option. If all tests
pass, you are ready to install pyxfoil on your system.  Else try to
investigate the build process or add a ticket to the project tracker.
Note that you can run a particular test in the following manner::

    $ PYTHONPATH=.:$PYTHONPATH \
    LD_LIBRARY_PATH=build:$LD_LIBRARY_PATH \
    python pyxfoil/tests/test_run_user_stories.py -cmd ./Xfoil/xfoil \
    TestRunStories.test_export_airfoil_data

Installing pyxfoil
------------------
The installation is done as administrator by::

    $ python setup.py install

Running examples
----------------
Some examples are provided for illustrating pyxfoil use cases::

    $ cd examples

For computing airfoils from Python by using Xfoil::

    $ python compute_airfoils.py

The mixed airfoil should be saved in the following file::

    $ head airfoil-naca2412-0.4naca4321.txt

For computing results from the angle of attack and from the lift
coefficient::

    $ python compute_alfa_cl.py

For a sweep across various angles of attack (note that the above mixed
airfoil file must be present)::

    $ python compute_sweep.py

Interactive use
---------------
By using the enhanced interactive Python shell, ipython, in the pylab
mode you can reproduce the Xfoil behavior::

    $ ipython -pylab

    : P = pylab
    : import pyxfoil

    : eng = pyxfoil.give_engine()
    : airfoil = eng.compute_naca(4321)
    : P.plot(airfoil.xcoords, airfoil.ycoords)
    : P.axis('equal')
    : P.grid()
    : P.clf()

    : oper = eng.start(pyxfoil.Oper)
    : oper.use_visc(1000)
    : oper.compute_cl(0.6)
    False
    : oper.use_itmax(300)
    : oper.recompute()
    True
    : eng.get('adeg')
    18.475204467773438
    : P.plot(eng.get('xcrds'), -eng.get('cpv'))
    : P.clf()
    : oper.close()

    : naca2412 = eng.compute_naca(2412)
    : airf = eng.create_mixed_airfoil('mix', naca2412, airfoil, 0.3)
    : oper = eng.start(pyxfoil.Oper)
    : alfas = P.arange(-6, 20)
    : coeffs = P.zeros((26, 3))
    : for idx, alfa in enumerate(alfas):
    :    assert oper.compute_alfa(alfa)
    :    coeffs[idx, :] = eng.get_many(['CL', 'CD', 'CM'])
    :
    : P.plot(alfas, coeffs[:, 0])
    : P.plot(alfas, coeffs[:, 1])
    : res = P.concatenate((alfas.reshape(-1, 1), coeffs), axis=1)
    : P.savetxt('coeffs-mixed.txt', res, fmt='%+.3e')

Then press 'Ctrl + d' for quitting ipython. The coefficients should be
available in the file::

    $ head coeffs-mixed.txt

Other use cases could be imagined now that the interactive work
is delegated to Python.

Contact
-------
André Espaze <andre.espaze@logilab.fr>
Linkesh Diwan <swiftarrow9@gmail.com>
Commercial support is also available at <contact@logilab.fr> or visit
http://www.logilab.fr

Xfoil resources
---------------
The useful resources for understanding xfoil are:

    - the main site at http://web.mit.edu/drela/Public/web/xfoil/
    - the main documentation 'xfoil_doc.txt' or a PDF version at
    http://openae.org/files/resources/xfoil/xfoil_doc.pdf
    - a tutorial at
    http://cobweb.ecn.purdue.edu/~aae333/XFOIL/Tutorial/Tutorial%20for%20XFoil.htm
    - the sessions written in 'sessions.txt'

Appendix: distributions prerequisites
-------------------------------------
Ubuntu
~~~~~~
For building pyxfoil, you will require the packages::

    python
    scons
    gcc
    gfortran
    libx11-dev
    python-dev
    python-numpy

For running pyxfoil, you will require::

    python
    python-numpy

First thing to do is satisfy dependencies. For this, make sure you have
python installed::

    $ python

If you get no errors, then your good to go.  Unless there is something very
strange about your Ubuntu install, you should have no problems, and you will
be dropped inside a shell like so::

    >>>

Exit the shell by typing exit() <return>::

    >>>> exit()
    $

If you DID get some errors, then it means that you don't have python installed
on your system.  In that case, your installation is different from the herd,
and you probably know what you're doing.  If not, install python::

    $ sudo apt-get install python

Now we need to install the required packages.  Run the following command,
entering your password when necessary::

    $ sudo apt-get install python-dev python-numpy gcc gfortran \
    scons libx11-dev

Once that's done processing, we can start the build process.  Extract
pyxfoil to a directory, and enter that directory in terminal::

    $ cd pyxfoil-0.1/

Finally start the build::

    $ scons -Q

Assuming that you got no errors, you are set to go on to other steps below.  If
you did get errors, it's time to file a bug report.

